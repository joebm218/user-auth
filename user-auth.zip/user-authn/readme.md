# API for Downroute Expense Management 

cp .env-example .env

and modify the environment variables

npm start