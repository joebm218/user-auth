

app.get('/test3', test3Handler);
app.get('/test3', test3Handler);
app.get('/test3', test3Handler);
app.get('/test3', test3Handler);